# -*- coding: utf-8 -*-
#
from django.dispatch import Signal

on_app_ready = Signal()
