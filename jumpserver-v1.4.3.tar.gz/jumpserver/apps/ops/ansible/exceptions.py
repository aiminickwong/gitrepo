# -*- coding: utf-8 -*-
#

__all__ = [
    'AnsibleError'
]


class AnsibleError(Exception):
    pass
