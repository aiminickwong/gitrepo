权限管理模块
=============

这里介绍权限管理功能。

.. toctree::
   :maxdepth: 1

   permission_asset_authorized
