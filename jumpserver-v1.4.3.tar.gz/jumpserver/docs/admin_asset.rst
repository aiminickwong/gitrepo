资产管理模块
=============

这里介绍资产管理模块功能。

.. toctree::
   :maxdepth: 1
   
   asset_list
   asset_admin_user
   asset_system_user
   asset_label